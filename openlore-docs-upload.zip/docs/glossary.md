# Glossary

The terms you'll meet across the OpenLore docs, in one place. Each entry links to the page that covers it properly.

## Agent instructions

Text a running server prints to tell an agent how to use it. `teach` explains OpenLore and helps choose a workflow, `agents` prints a snippet for `AGENTS.md`, and `agents-shellm` prints a skill file for headlong/shellm. Learn more in [ways to use OpenLore](how-to/usage.md).

## Baseline

The size a file had the first time it was written under a growth limit. Later writes can't grow the file past the baseline times the rule's `growth`. Learn more in [folder rules](concepts/folder-rules.md).

## Docset

A named part of the served tree, plus the policy that governs it: who can read it, who can change it, which rules check it and where contributions land. Docsets are declared in `lore.json`. Learn more in [docsets](concepts/docsets.md).

## Docstore

Where the server keeps a versioned copy of everything that didn't start life in a docset: synced folders, Git repositories, Claude Code instructions and memory, and imported skills. A store isn't visible to agents until a projection serves it. Learn more in [knowledge gateway](concepts/knowledge-gateway.md).

## Folder rules

Checks that run on every write, such as size limits or format checks. A write that breaks a rule is rejected, and the agent is told why. Some checks, like broken-link detection, only run when you call `lore validate`. Learn more in [folder rules](concepts/folder-rules.md).

## Grant

What a role can do in a docset. `ro` can read. `rw` can read and write. `publish` can read the whole docset but only add new files inside its inbox. Learn more in [docsets](concepts/docsets.md).

## Growth limit

A folder rule that caps a file at its baseline times a `growth` multiplier, so documents can't keep swelling every time an agent edits them. Learn more in [folder rules](concepts/folder-rules.md).

## Guest

The built-in role for keyless callers, or callers with an unrecognised key if you allow them. Guests can only be given read-only access. Learn more in [auth](concepts/auth.md).

## headlong and shellm

headlong is a third-party agent project. shellm is its engine, which works by writing and running bash, so it can use OpenLore over SSH with no adapter. Learn more in [run headlong / shellm](how-to/shellm.md).

## Home

A docset that belongs to one identity. It shows up as `$HOME`, so `cd` and `~` work as you'd expect. Anything projected under `/user/<identity>/` is private to that person. Learn more in [docsets](concepts/docsets.md).

## Identity

Who or what is connecting: a person or an agent. Every transport resolves a caller to an identity in `lore.json`, by SSH key, passkey or OAuth token, and the identity's roles decide what it can see. Learn more in [auth](concepts/auth.md).

## Inbox

A folder inside a docset where identities with the `publish` grant can add new documents. They can't overwrite existing documents or delete anything, so you can accept work from an agent you don't fully trust. Learn more in [let an agent publish into an inbox](how-to/publish-to-inbox.md).

## Knowledge gateway

The part of OpenLore that brings knowledge you keep elsewhere into the server and shows it to agents as ordinary docsets, while the original stays where it is. Knowledge Import is its first phase. Learn more in [knowledge gateway](concepts/knowledge-gateway.md).

## Knowledge repository

A Git repository holding a server's settings (`openlore.yml` and `lore.json`) and, under `home/`, what each person syncs into it. Commit it and a teammate can clone it, run `lore login` and get the same server. Learn more in [create a knowledge repository](start/create-knowledge-repository.md).

## `lore`

The client that ships beside the `openlore` server. You run it from a knowledge repository to log in, sync sources and manage the server. Learn more in the [lore CLI reference](reference/lore-cli.md).

## `lore.json`

The policy file. It defines your docsets, roles and identities. Its location is set by `auth_file` in `openlore.yml`. Learn more in [docsets](concepts/docsets.md).

## MCP

Model Context Protocol, a standard way for AI tools to connect to services. OpenLore serves MCP at `/mcp` on its HTTP port, and over stdio with `openlore mcp`. Learn more in [transports](concepts/transports.md).

## OKF

Open Knowledge Format, an open spec for structured knowledge bundles. OpenLore can check files against it as they're written, and `lore validate` checks whole bundles. Learn more in [plugins and formats](concepts/plugins.md).

## `openlore.yml`

The server configuration file: ports, transports, writing, plugins and where `lore.json` lives. It also marks the root of a knowledge repository. Learn more in the [openlore.yml reference](reference/openlore-yml.md).

## Projection

A docset whose contents come from a store in the docstore. You can narrow it to a subfolder or filter, and give it grants like any other docset. Projections are read-only on every transport. Learn more in [knowledge gateway](concepts/knowledge-gateway.md).

## Role

A named group of permissions. You give roles grants on docsets, then assign roles to identities. Learn more in [auth](concepts/auth.md).

## Skills collection

A folder OpenLore treats as a set of Agent Skills, so agents can find, validate and share them. Skills can be imported from public Git repositories and kept up to date. Learn more in [plugins and formats](concepts/plugins.md).

## Source

Somewhere knowledge comes from: a folder, a Git repository, or the instructions and memory Claude Code keeps. Each person lists theirs in `home/<identity>/sources.yaml`, and `lore sync` pushes them to the docstore. Learn more in [import knowledge](start/import-knowledge.md).

## Stale write

A write to a file that changed after the agent last read it. OpenLore rejects it rather than silently overwriting newer work. Learn more in [writing and publishing](concepts/writing.md).

## Transport

A way of reaching the server: SSH, SFTP, MCP, the JSON API or the dashboard. Every transport sees the same files with the same access for the same identity. Learn more in [transports](concepts/transports.md).

## Virtual filesystem

What agents see when they connect. It behaves like a normal filesystem, but each identity only sees what it's allowed to, and commands like `cat` and `grep` are built into OpenLore rather than run on the host. Learn more in [what is OpenLore](introduction.md).
